<section class="page-header bg_img" data-background="{{ imageFile('public/assets/frontend/images/hero/hero-bg.jpg') }}">
    <div class="container">
        <div class="page-content">
            <h2 class="title">{{ $title }}</h2>
        </div>
    </div>
</section>
