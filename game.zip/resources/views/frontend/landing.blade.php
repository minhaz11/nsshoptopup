@extends('layouts.frontend')

@section('content')
    @include('sections.banner')
    @include('sections.promotion_one')
    @include('sections.promo_one')
    {{-- @include('sections.promotion_two') --}}
    @include('sections.promo_two')
@endsection
